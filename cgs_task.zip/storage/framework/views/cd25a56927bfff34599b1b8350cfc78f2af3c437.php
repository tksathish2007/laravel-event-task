<!DOCTYPE html>
<html>
<head>
    <title>View Products</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>

    <!-- <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/jquery-editable/css/jquery-editable.css" rel="stylesheet"/>
    <script>$.fn.poshytip={defaults:null}</script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/jquery-editable/js/jquery-editable-poshytip.min.js"></script> -->

    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/dt/jqc-1.12.4/dt-1.11.0/b-2.0.0/sl-1.3.3/datatables.min.css"/>
	<link rel="stylesheet" type="text/css" href="Editor-2.0.5/css/editor.dataTables.css">
	 
	<script type="text/javascript" src="https://cdn.datatables.net/v/dt/jqc-1.12.4/dt-1.11.0/b-2.0.0/sl-1.3.3/datatables.min.js"></script>
	<script type="text/javascript" src="Editor-2.0.5/js/dataTables.editor.js"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
</head>
<body>
      
<div class="container">
	<div id="add_product_div" class="add_product d-none">
	    <h1>Add Product</h1>
	    <form method="post" id="addProductForm" action="<?php echo e(route('products.create')); ?>" enctype="multipart/form-data">

            <!-- CROSS Site Request Forgery Protection -->
            <?php echo csrf_field(); ?>


            <div class="form-group">
                <label>Product Category</label>
                <select id="category" name="category" class="form-control">
                	<option value='' disabled="">Select Product Category</option>

                	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<option value='<?php echo e($category->id); ?>'><?php echo e($category->name); ?></option>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

            <div class="form-group">
                <label>Product Model</label>
                <select id="model" name="model" class="form-control">
                	<option value='' disabled="">Select Product Model</option>

                	<?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                		<option value='<?php echo e($model->id); ?>'><?php echo e($model->name); ?></option>
                	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </select>
            </div>

            <div class="form-group">
                <label>Product Name</label>
                <input type="text" class="form-control" name="name" id="name">
            </div>

            <div class="form-group">
                <label>Product Selling Price</label>
                <input type="number" class="form-control" name="selling_price" id="selling_price">
            </div>

            <div class="form-group">
                <label>Product Cost Price</label>
                <input type="number" class="form-control" name="cost_price" id="cost_price">
            </div>

            <div class="form-group">
                <label>GST (%)</label>
                <input type="number" class="form-control" name="gst" id="gst">
            </div>

            <div class="form-group">
                <label>SGST (%)</label>
                <input type="number" class="form-control" name="sgst" id="sgst">
            </div>

            <div class="form-group">
                <label>IGST (%)</label>
                <input type="number" class="form-control" name="igst" id="igst">
            </div>

            <div class="form-group">
                <label>Product Images</label>
                <input type="file" class="form-control" multiple name="images[]" id="images">
            </div>

            <div class="form-group">
                <label>Product Description</label>
                <textarea class="form-control" name="description" id="description" rows="4"></textarea>
            </div>

            <input type="submit" name="submit" value="Submit" class="btn btn-primary">
            <input type="reset" name="reset" value="Reset" class="btn btn-danger" id="show_products">
        </form>
	</div>

	<div id="list_of_products_div" class="list_of_products">
	    <h1>List Of Products</h1>
	    <button class="btn btn-success float-right" id="add_product">Add Product</button>
	    <br/><br/>
	    <table class="table table-bordered data-table" id="table">
	        <thead>
	            <tr>
	                <th>#</th>
	                <th>Image</th>
	                <th>Name</th>
	            </tr>
	        </thead>
	        
	    </table>
	</div>
</div>
     
</body>
     
<script type="text/javascript">
    // $.fn.editable.defaults.mode = 'inline';
  
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
    }); 
  
  //   $('.update').editable({
		// url: "<?php echo e(route('products.update')); ?>",
		// type: 'text',
		// pk: 1,
		// name: 'name',
		// title: 'Enter name'
  //   });

  	editor = new $.fn.dataTable.Editor( {
        ajax: "<?php echo e(route('products.update')); ?>",
        table: "#example",
        fields: [ 
        	{
                label: "ID:",
                name: "idd"
            },
        	{
                label: "Name:",
                name: "name"
            }
        ]
    } );
 
    // Activate an inline edit on click of a table cell
    $('#table').on( 'click', 'tbody td:not(:first-child)', function (e) {
        editor.inline( this );
    } );
 
    $('#table').DataTable( {
        dom: "Bfrtip",
       	ajax: "<?php echo e(route('products.all')); ?>",
        order: [[ 1, 'asc' ]],
        columns: [
            { data: "id" },
            { data: "first_name" },
        ],
        select: {
            style:    'os',
            selector: 'td:first-child'
        }
    } );

    function handlyShowHideDiv(type) {
    	if(type == 'add_product') {
	    	$("#add_product_div").removeClass('d-none')
	    	$("#list_of_products_div").addClass('d-none')    	    		
    	} else if(type == 'list_of_products')  {
	    	$("#list_of_products_div").removeClass('d-none')
	    	$("#add_product_div").addClass('d-none')    		
    	}
    }

    $("#add_product").on('click', function() {
    	handlyShowHideDiv('add_product');
    })

    $("#show_products").on('click', function() {
    	handlyShowHideDiv('list_of_products');
    })

    $(document).ready(function() {
        var formValidate = $("#addProductForm").validate({
            rules: {
                category: "required",
                model: "required",
                name: "required",
                selling_price: "required",
                cost_price: "required",
                gst: "required",
                sgst: "required",
                igst: "required",
                'images[]': "required",
                description: "required",
            }
        });

	    $('#addProductForm').submit(function(e) {
	       if(!formValidate.valid()) return;
	       e.preventDefault();

	       let formData = new FormData(this);

	       $.ajax({
	          	type:'POST',
	          	url: $("#addProductForm").attr('action'),
	           	data: formData,
	           	contentType: false,
	           	processData: false,
	           	success: (response) => {
					if (response) {
						// this.reset();
					}
					window.reload();
	           	},
	           	error: function(response) {
	              	console.log(response);
					window.reload();
	           	}
	       });
	  	});
    });
</script>

<style>
label.error {
	color: #f00;
}
.container {
	padding: 20px;
}
</style>
</html><?php /**PATH E:\xampp\htdocs\interview\bright_task\resources\views/products/view.blade.php ENDPATH**/ ?>
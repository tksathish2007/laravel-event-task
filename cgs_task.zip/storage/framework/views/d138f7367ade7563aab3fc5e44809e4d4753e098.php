<!DOCTYPE html>
<html>
<head>
    <title>View Products</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.min.css" />
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/jquery-editable/css/jquery-editable.css" rel="stylesheet"/>
    <script>$.fn.poshytip={defaults:null}</script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/jquery-editable/js/jquery-editable-poshytip.min.js"></script>
</head>
<body>
      
<div class="container">
	<div id="add_product_div" class="add_product hidden">
	    <h1>Add Product</h1>
	</div>

	<div id="list_of_products_div" class="list_of_products">
	    <h1>List Of Products</h1>
	    <button class="btn btn-success pull-right" id="add_product">Add Product</button>
	    <table class="table table-bordered data-table">
	        <thead>
	            <tr>
	                <th>No</th>
	                <th>Name</th>
	            </tr>
	        </thead>
	        <tbody>
	            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <tr>
	                    <td><?php echo e($product->id); ?></td>
	                    <td>
	                        <a href="" class="update" data-name="name" data-type="text" data-pk="<?php echo e($product->id); ?>" data-title="Enter name"><?php echo e($product->name); ?></a>
	                    </td>
	                    <td>
	                        <a href="" class="update" data-name="email" data-type="text" data-pk="<?php echo e($product->id); ?>" data-title="Enter email"><?php echo e($product->email); ?></a>
	                    </td>
	                </tr>
	            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	        </tbody>
	    </table>
	</div>
</div>
     
</body>
     
<script type="text/javascript">
    $.fn.editable.defaults.mode = 'inline';
  
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
    }); 
  
    $('.update').editable({
		url: "<?php echo e(route('users.update')); ?>",
		type: 'text',
		pk: 1,
		name: 'name',
		title: 'Enter name'
    });

    function handlyShowHideDiv(type) {
    	if(type == 'add_product') {
	    	$("#add_product_div").removeClass('hidden')
	    	$("#list_of_products_div").addClass('hidden')    	    		
    	} else if(type == 'list_of_products')  {
	    	$("#list_of_products_div").removeClass('hidden')
	    	$("#add_product_div").addClass('hidden')    		
    	}
    }

    $("#add_product").on('click', function() {
    	handlyShowHideDiv('add_product');
    })

    $("#show_products").on('click', function() {
    	handlyShowHideDiv('list_of_products');
    })
</script>
</html><?php /**PATH E:\xampp\htdocs\interview\bright_task\resources\views/users/view.blade.php ENDPATH**/ ?>